<?php

declare(strict_types=1);

use TYPO3\CMS\Extbase\Utility\ExtensionUtility;
use TYPO3\CMS\Core\Utility\ExtensionManagementUtility;
use Equed\EquedLms\Controller\CertificateController;
use Equed\EquedLms\Controller\VerifyController;
use Equed\EquedLms\Service\InstructorMatchingService;

// Zertifikatsanzeige als Card
ExtensionUtility::configurePlugin(
    'Equed.EquedLms',
    'CertificationCard',
    [
        CertificateController::class => 'showCard',
    ],
    [
        CertificateController::class => 'showCard',
    ]
);

// Zertifikatsprüfung (Verify)
ExtensionUtility::configurePlugin(
    'Equed.EquedLms',
    'VerifyCertificate',
    [
        VerifyController::class => 'show',
    ],
    [
        VerifyController::class => 'show',
    ]
);

// Registrierung des InstructorMatchingService
$GLOBALS['TYPO3_CONF_VARS']['SC_OPTIONS']['extbase']['services']['InstructorMatchingService'] = [
    'class' => 'Equed\\EquedLms\\Service\\InstructorMatchingService',
    'constructorArguments' => [
        'instructorRepository' => \TYPO3\CMS\Core\Utility\GeneralUtility::makeInstance(\Equed\EquedLms\Domain\Repository\InstructorRepository::class),
    ]
];

// ⚠️ Kein addStaticFile nötig, da setup.typoscript korrekt eingebunden ist (lt. deinem Hinweis)