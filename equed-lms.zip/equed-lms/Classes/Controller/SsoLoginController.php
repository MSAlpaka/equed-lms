<?php
namespace Equed\EquedLms\Controller;

use TYPO3\CMS\Extbase\Mvc\Controller\ActionController;

class SsoLoginController extends ActionController
{
    public function indexAction(): void
    {
        // Zeigt einfach das zugehörige Template an
    }
}