<?php
namespace Equed\EquedLms\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Repository;

class CourseRepository extends Repository
{
    // Eigene Abfragen oder Filter hier hinzufügen
}