<?php
namespace Equed\EquedLms\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Repository;

class QuizQuestionRepository extends Repository
{
    // Füge hier benötigte Methoden für Abfragen hinzu
}