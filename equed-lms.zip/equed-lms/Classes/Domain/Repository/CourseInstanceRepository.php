<?php

declare(strict_types=1);

namespace EquedLms\Domain\Repository;

use EquedLms\Domain\Model\CourseProgram;
use TYPO3\CMS\Extbase\Persistence\Repository;
use TYPO3\CMS\Extbase\Persistence\QueryInterface;

class CourseInstanceRepository extends Repository
{
    protected $defaultOrderings = [
        'startDate' => QueryInterface::ORDER_ASCENDING,
    ];

    /**
     * Finde alle öffentlichen Kursinstanzen eines Programms
     */
    public function findPublicByProgram(CourseProgram $program): array
    {
        $query = $this->createQuery();
        $query->matching(
            $query->logicalAnd([
                $query->equals('program', $program),
                $query->equals('isPublic', true),
            ])
        );
        return $query->execute()->toArray();
    }

    /**
     * Finde alle Instanzen an einem bestimmten Center
     */
    public function findByCenter(int $centerUid): array
    {
        $query = $this->createQuery();
        $query->matching(
            $query->equals('center', $centerUid)
        );
        return $query->execute()->toArray();
    }

    /**
     * Finde alle laufenden Instanzen ab heute
     */
    public function findUpcoming(): array
    {
        $query = $this->createQuery();
        $query->matching(
            $query->greaterThanOrEqual('startDate', new \DateTimeImmutable('today'))
        );
        return $query->execute()->toArray();
    }

    /**
     * Finde alle Instanzen, denen ein bestimmter FE-User (Instructor) zugewiesen ist
     */
    public function findByInstructor(int $userUid): array
    {
        $query = $this->createQuery();
        $query->matching(
            $query->contains('instructors', $userUid)
        );
        return $query->execute()->toArray();
    }

    /**
     * Optional: Finde alle Instanzen, die voll sind
     */
    public function findFullyBooked(): array
    {
        $query = $this->createQuery();
        $query->statement(
            'SELECT * FROM tx_equedlms_domain_model_courseinstance ci
             WHERE max_participants > 0 AND (
                 SELECT COUNT(*) FROM tx_equedlms_domain_model_usercourserecord ucr
                 WHERE ucr.course_instance = ci.uid
             ) >= ci.max_participants'
        );
        return $query->execute(true);
    }
}