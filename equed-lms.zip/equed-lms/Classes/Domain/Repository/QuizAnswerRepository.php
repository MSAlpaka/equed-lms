<?php
declare(strict_types=1);

namespace Equed\EquedLms\Domain\Repository;

use TYPO3\CMS\Extbase\Persistence\Repository;

class QuizAnswerRepository extends Repository
{
    // Custom methods können hier später ergänzt werden
}