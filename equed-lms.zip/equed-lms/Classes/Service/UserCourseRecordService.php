<?php

declare(strict_types=1);

namespace EquedLms\Service;

use EquedLms\Domain\Repository\UserCourseRecordRepository;
use EquedLms\Domain\Model\UserCourseRecord;
use EquedLms\Domain\Model\FrontendUser;

class UserCourseRecordService
{
    protected UserCourseRecordRepository $userCourseRecordRepository;

    public function __construct(UserCourseRecordRepository $userCourseRecordRepository)
    {
        $this->userCourseRecordRepository = $userCourseRecordRepository;
    }

    public function hasAlreadyBooked(int $userId, int $programId): bool
    {
        return count($this->userCourseRecordRepository->findByUserAndProgram($userId, $programId)) > 0;
    }

    public function markAsCompleted(UserCourseRecord $record, FrontendUser $instructor): void
    {
        $record->setStatus('completed');
        $record->setMarkedAsCompletedBy($instructor);
        $record->setMarkedAsCompletedAt(new \DateTimeImmutable());
        $this->userCourseRecordRepository->update($record);
    }

    public function validateRecord(UserCourseRecord $record, FrontendUser $certifier): void
    {
        $record->setValidatedBy($certifier);
        $record->setValidatedAt(new \DateTimeImmutable());
        $record->setCertificateIssued(true);
        $this->userCourseRecordRepository->update($record);
    }
}