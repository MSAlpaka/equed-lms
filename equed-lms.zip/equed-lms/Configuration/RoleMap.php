<?php

return [
    // Kursname (klein, ohne Sonderzeichen) => User-Feld (boolean)
    'instructor development in hoofcare' => 'is_instructor',
    'instructor certifier' => 'is_certifier',

    // Weitere Rollen später einfach ergänzen
];