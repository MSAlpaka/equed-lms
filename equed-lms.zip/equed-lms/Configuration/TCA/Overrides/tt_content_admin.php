<?php

defined('TYPO3') or die();

use TYPO3\CMS\Extbase\Utility\ExtensionUtility;

ExtensionUtility::registerPlugin(
    'EquedLms',
    'AdminDashboard',
    'Admin Dashboard'
);