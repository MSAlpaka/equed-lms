<?php

declare(strict_types=1);

return [
    '/submission-review' => 'instructor',
    '/certificate'       => 'certifier',
    '/admin'             => 'admin',
    '/certify'           => 'certifier',
];