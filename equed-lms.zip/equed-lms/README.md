# equed-lms

This is the official TYPO3 LMS extension used on training.equed.eu, featuring:
- Course & Lesson management
- Certification flow
- Secure OAuth-based SSO login

Only the SSO module is loaded on other EquEd domains (equed.eu, shop.equed.eu).

## Installation (Composer)

```bash
composer require equed/equed-lms:@dev