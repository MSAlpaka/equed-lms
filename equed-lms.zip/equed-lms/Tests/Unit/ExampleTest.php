<?php

declare(strict_types=1);

namespace Equed\EquedLms\Tests\Unit;

use PHPUnit\Framework\TestCase;

final class ExampleTest extends TestCase
{
    public function testExampleReturnsTrue(): void
    {
        $this->assertTrue(true);
    }
}